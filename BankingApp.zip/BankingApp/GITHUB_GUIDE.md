# Upload BankingApp To GitHub 🚀

## 1. Create GitHub Repository

Go to:
https://github.com/new

Repository Name:
BankingApp

Do NOT initialize with README.

------------------------------------------------

## 2. Open Terminal

Navigate into project:

cd BankingApp

------------------------------------------------

## 3. Initialize Git

git init

------------------------------------------------

## 4. Add Files

git add .

------------------------------------------------

## 5. Commit

git commit -m "Initial banking app project"

------------------------------------------------

## 6. Connect GitHub Repo

Replace YOUR_USERNAME:

git remote add origin https://github.com/YOUR_USERNAME/BankingApp.git

------------------------------------------------

## 7. Push Project

git branch -M main

git push -u origin main

------------------------------------------------

## 8. Done ✅

Your project will now be available on GitHub.
