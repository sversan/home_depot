<!DOCTYPE html>
<html>
<head>
    <title>Banking Application</title>
</head>
<body>

<h1>Welcome to BankingApp</h1>

<a href="views/login.jsp">Login</a><br>
<a href="views/register.jsp">Register</a>

</body>
</html>
