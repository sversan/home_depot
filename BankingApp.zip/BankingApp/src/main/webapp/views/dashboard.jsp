<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h1>Bank Dashboard</h1>

<ul>
    <li>Check Balance</li>
    <li>Deposit Money</li>
    <li>Withdraw Money</li>
    <li>Transfer Funds</li>
    <li>Transaction History</li>
</ul>

</body>
</html>
