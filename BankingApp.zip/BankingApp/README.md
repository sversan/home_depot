# BankingApp

Java JSP Banking Application using:
- JSP
- Servlets
- JDBC
- MySQL
- Apache Tomcat

## Run

1. Import as Maven project
2. Create database using database.sql
3. Configure DB credentials in DBConnection.java
4. Deploy to Tomcat
5. Open:
   http://localhost:8080/BankingApp
